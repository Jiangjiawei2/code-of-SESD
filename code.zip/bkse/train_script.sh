python3.7 train.py -opt options/REDS/wsharp_woVAE.yml
